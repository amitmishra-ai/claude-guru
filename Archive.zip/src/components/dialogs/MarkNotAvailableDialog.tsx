import { useMemo, useState } from "react";
import { AlertTriangle } from "lucide-react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Chip from "@mui/material/Chip";
import Typography from "@mui/material/Typography";
import { useAppSelector, useAppDispatch } from "@/store";
import { setOpenNotAvailable } from "@/store/slices/uiSlice";
import {
  addUnavailable,
  setNaStartDate,
  setNaEndDate,
  setNaReason,
  setNaStart,
  setNaEnd,
} from "@/store/slices/availabilitySlice";
import { declineSession } from "@/store/slices/sessionsSlice";
import { respondToRequest } from "@/store/slices/requestsSlice";
import { pushToast } from "@/store/slices/toastsSlice";
import { TIME_START, TIME_END, timeOptions12 } from "@/lib/constants";
import { parseHHMM, fmtTime12, toYmd, addDays } from "@/lib/helpers";
import type { NA } from "@/lib/types";

/**
 * §10: Multi-day leave segmentation helper.
 *
 * Given a date range with start/end times, create leave blocks per day segment:
 * - First day: start at selected start time, end at TIME_END (20:00)
 * - Middle days: full calendar window TIME_START (08:00) to TIME_END (20:00)
 * - Last day: start at TIME_START (08:00), end at selected end time
 * - Single day: start at selected start time, end at selected end time
 */
function generateLeaveSegments(
  startDateYmd: string,
  endDateYmd: string,
  startMins: number,
  endMins: number,
  reason: string
): Omit<NA, "id">[] {
  const segments: Omit<NA, "id">[] = [];
  const startDate = new Date(`${startDateYmd}T00:00:00`);
  const endDate = new Date(`${endDateYmd}T00:00:00`);
  const now = Date.now();

  // Single day
  if (startDateYmd === endDateYmd) {
    segments.push({
      dateYmd: startDateYmd,
      start: startMins,
      end: endMins,
      reason: reason || "Leave",
      createdAt: now,
    });
    return segments;
  }

  // Multi-day: iterate from start to end date
  let current = startDate;
  let dayIndex = 0;
  while (toYmd(current) <= endDateYmd) {
    const ymd = toYmd(current);
    const isFirst = ymd === startDateYmd;
    const isLast = ymd === endDateYmd;

    const segStart = isFirst ? startMins : TIME_START;
    const segEnd = isLast ? endMins : TIME_END;

    segments.push({
      dateYmd: ymd,
      start: segStart,
      end: segEnd,
      reason: reason || "Leave",
      createdAt: now + dayIndex, // unique createdAt per segment
    });

    current = addDays(current, 1);
    dayIndex++;
  }

  return segments;
}

/** Overlap predicate: aStart < bEnd && bStart < aEnd */
function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number) {
  return aStart < bEnd && bStart < aEnd;
}

export function MarkNotAvailableDialog() {
  const dispatch = useAppDispatch();
  const open = useAppSelector((s) => s.ui.openNotAvailable);
  const naStartDate = useAppSelector((s) => s.availability.naStartDate);
  const naEndDate = useAppSelector((s) => s.availability.naEndDate);
  const naReason = useAppSelector((s) => s.availability.naReason);
  const naStart = useAppSelector((s) => s.availability.naStart);
  const naEnd = useAppSelector((s) => s.availability.naEnd);
  const sessions = useAppSelector((s) => s.sessions.items);
  const sessionDeclined = useAppSelector((s) => s.sessions.sessionDeclined);
  const requests = useAppSelector((s) => s.requests.items);

  const [autoDecline, setAutoDecline] = useState(false);

  /* ── Validation (§10): end must be after start in datetime terms ───── */
  const isValid = useMemo(() => {
    if (!naStartDate || !naEndDate) return false;
    if (naStartDate > naEndDate) return false;
    if (naStartDate === naEndDate) {
      return parseHHMM(naEnd) > parseHHMM(naStart);
    }
    return true;
  }, [naStartDate, naEndDate, naStart, naEnd]);

  /* ── §10: Detect overlapping scheduled sessions ────────────────────── */
  const conflictingSessions = useMemo(() => {
    if (!naStartDate || !naEndDate) return [];
    const segments = generateLeaveSegments(
      naStartDate,
      naEndDate,
      parseHHMM(naStart),
      parseHHMM(naEnd),
      ""
    );

    return sessions.filter((s) => {
      if (sessionDeclined[s.id]) return false;
      // Check if any leave segment overlaps this session
      return segments.some(
        (seg) =>
          seg.dateYmd === s.dateYmd && overlaps(seg.start, seg.end, s.start, s.end)
      );
    });
  }, [sessions, sessionDeclined, naStartDate, naEndDate, naStart, naEnd]);

  /* ── §10: Detect overlapping pending requests ──────────────────────── */
  const conflictingRequests = useMemo(() => {
    if (!naStartDate || !naEndDate) return [];
    const segments = generateLeaveSegments(
      naStartDate,
      naEndDate,
      parseHHMM(naStart),
      parseHHMM(naEnd),
      ""
    );

    return requests.filter((r) => {
      if (r.response !== "pending") return false;
      return segments.some(
        (seg) =>
          seg.dateYmd === r.dateYmd && overlaps(seg.start, seg.end, r.start, r.end)
      );
    });
  }, [requests, naStartDate, naEndDate, naStart, naEnd]);

  const totalConflicts = conflictingSessions.length + conflictingRequests.length;

  const handleConfirm = () => {
    const startMins = parseHHMM(naStart);
    const endMins = parseHHMM(naEnd);
    const reason = naReason.trim() || "Leave";

    /* §10: create leave blocks per day segment */
    const segments = generateLeaveSegments(naStartDate, naEndDate, startMins, endMins, reason);
    segments.forEach((seg, i) => {
      dispatch(
        addUnavailable({
          id: `na-${Date.now()}-${i}`,
          ...seg,
        })
      );
    });

    /* §10: on submit with auto-decline */
    if (autoDecline && totalConflicts > 0) {
      // Auto-decline conflicting sessions
      conflictingSessions.forEach((s) => {
        dispatch(declineSession({ id: s.id, dateYmd: s.dateYmd }));
      });
      // Auto-mark conflicting requests as unavailable
      conflictingRequests.forEach((r) => {
        dispatch(respondToRequest({ id: r.id, response: "unavailable" }));
      });

      const parts: string[] = [];
      if (conflictingSessions.length > 0) parts.push(`${conflictingSessions.length} session(s) auto-declined`);
      if (conflictingRequests.length > 0) parts.push(`${conflictingRequests.length} request(s) marked unavailable`);

      dispatch(
        pushToast({
          title: "Marked unavailable",
          description: `${naStartDate} to ${naEndDate} • ${parts.join(", ")}`,
        })
      );
    } else {
      dispatch(
        pushToast({
          title: "Marked unavailable",
          description: `${naStartDate} to ${naEndDate}${segments.length > 1 ? ` (${segments.length} days)` : ""}`,
        })
      );
    }

    dispatch(setOpenNotAvailable(false));
    dispatch(setNaReason(""));
    setAutoDecline(false);
  };

  return (
    <Dialog
      open={open}
      onClose={() => dispatch(setOpenNotAvailable(false))}
      PaperProps={{ className: "rounded-2xl" }}
      maxWidth="sm"
      fullWidth
    >
      <DialogTitle>Mark not available</DialogTitle>

      <DialogContent>
        <div className="space-y-4 pt-1">
          <div className="rounded-2xl border bg-surface-container/30 p-3 text-sm text-on-surface-variant">
            Block off a date or period when you are not available for sessions.
          </div>

          <div className="grid grid-cols-2 gap-3">
            <TextField
              label="Start date"
              type="date"
              value={naStartDate}
              onChange={(e) => dispatch(setNaStartDate(e.target.value))}
              size="small"
              fullWidth
              slotProps={{ inputLabel: { shrink: true } }}
            />
            <TextField
              label="End date"
              type="date"
              value={naEndDate}
              onChange={(e) => dispatch(setNaEndDate(e.target.value))}
              size="small"
              fullWidth
              slotProps={{ inputLabel: { shrink: true } }}
            />
          </div>

          {/* Time pickers */}
          <div className="grid grid-cols-2 gap-3">
            <FormControl fullWidth size="small">
              <InputLabel>Start time</InputLabel>
              <Select
                label="Start time"
                value={naStart}
                onChange={(e) => dispatch(setNaStart(e.target.value))}
              >
                {timeOptions12.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth size="small">
              <InputLabel>End time</InputLabel>
              <Select
                label="End time"
                value={naEnd}
                onChange={(e) => dispatch(setNaEnd(e.target.value))}
              >
                {timeOptions12.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </div>

          {/* Validation error */}
          {naStartDate && naEndDate && !isValid && (
            <Typography variant="caption" sx={{ color: 'error.main' }}>
              End date/time must be after start date/time.
            </Typography>
          )}

          <TextField
            label="Reason (optional)"
            value={naReason}
            onChange={(e) => dispatch(setNaReason(e.target.value))}
            placeholder="E.g., vacation, personal leave"
            size="small"
            fullWidth
          />

          {/* §10: Conflict warning with counts before submit */}
          {totalConflicts > 0 && (
            <div className="space-y-2">
              <div className="flex items-start gap-2 rounded-2xl p-3" style={{ backgroundColor: '#fffbeb', border: '1px solid #fde68a' }}>
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" style={{ color: '#d97706' }} />
                <div>
                  <div className="text-sm font-semibold" style={{ color: '#92400e' }}>
                    {totalConflicts} conflicting item{totalConflicts > 1 ? "s" : ""}
                    {conflictingSessions.length > 0 && conflictingRequests.length > 0 && (
                      <span className="font-normal">
                        {" "}({conflictingSessions.length} session{conflictingSessions.length > 1 ? "s" : ""}, {conflictingRequests.length} request{conflictingRequests.length > 1 ? "s" : ""})
                      </span>
                    )}
                  </div>
                  <div className="mt-1 space-y-1">
                    {conflictingSessions.map((s) => (
                      <div key={s.id} className="text-xs" style={{ color: '#92400e' }}>
                        🔴 {s.title} &bull; {s.dateYmd} &bull; {fmtTime12(s.start)}–{fmtTime12(s.end)}
                      </div>
                    ))}
                    {conflictingRequests.map((r) => (
                      <div key={r.id} className="text-xs" style={{ color: '#92400e' }}>
                        🟡 {r.title} &bull; {r.dateYmd} &bull; {fmtTime12(r.start)}–{fmtTime12(r.end)}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <Chip
                label="Auto-decline sessions & mark requests unavailable"
                size="small"
                variant={autoDecline ? "filled" : "outlined"}
                onClick={() => setAutoDecline(!autoDecline)}
                sx={{
                  borderRadius: '9999px',
                  cursor: 'pointer',
                  ...(autoDecline
                    ? { bgcolor: '#fbbf24', color: '#78350f', '&:hover': { bgcolor: '#f59e0b' } }
                    : { borderColor: '#fde68a', color: '#92400e', '&:hover': { bgcolor: '#fffbeb' } }),
                }}
              />
            </div>
          )}
        </div>
      </DialogContent>

      <DialogActions>
        <Button variant="outlined" color="inherit" onClick={() => dispatch(setOpenNotAvailable(false))}>
          Cancel
        </Button>
        <Button variant="contained" onClick={handleConfirm} disabled={!isValid}>
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
}
