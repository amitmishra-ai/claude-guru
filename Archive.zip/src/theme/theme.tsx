import * as React from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

/**
 * Builds an MUI theme using the Great Learning design-system colors.
 * Light primary: #196ae5, Secondary: #ff9800
 * Dark primary: #66bbff, Secondary: #ffcc80
 */
function buildTheme(mode: "light" | "dark") {
  return createTheme({
    palette: {
      mode,
      primary: {
        main: mode === "light" ? "#196ae5" : "#66bbff",
        dark: mode === "light" ? "#0f4089" : "#3a9ae8",
        light: mode === "light" ? "#4788ea" : "#e8f0fc",
        contrastText: mode === "light" ? "#ffffff" : "rgba(0, 0, 0, 0.87)",
      },
      secondary: {
        main: mode === "light" ? "#ff9800" : "#ffcc80",
        dark: mode === "light" ? "#ef6c00" : "#ca9b52",
        light: mode === "light" ? "#ffb74d" : "#ffffb0",
        contrastText: mode === "light" ? "#ffffff" : "rgba(0, 0, 0, 0.87)",
      },
      error: {
        main: mode === "light" ? "#ff3333" : "#f44336",
        dark: mode === "light" ? "#d10b25" : "#d32f2f",
        light: mode === "light" ? "#f9494f" : "#e57373",
        contrastText: "#ffffff",
      },
      warning: {
        main: mode === "light" ? "#ffbf00" : "#ffa726",
        dark: mode === "light" ? "#ff6d00" : "#f57c00",
        light: mode === "light" ? "#ffd44d" : "#ffb74d",
        contrastText: mode === "light" ? "#ffffff" : "rgba(0, 0, 0, 0.87)",
      },
      info: {
        main: mode === "light" ? "#196ae5" : "#29b6f6",
        dark: mode === "light" ? "#0f4089" : "#0288d1",
        light: mode === "light" ? "#4788ea" : "#4fc3f7",
        contrastText: mode === "light" ? "#ffffff" : "rgba(0, 0, 0, 0.87)",
      },
      success: {
        main: mode === "light" ? "#22bb34" : "#66bb6a",
        dark: mode === "light" ? "#00880f" : "#388e3c",
        light: mode === "light" ? "#74d176" : "#81c784",
        contrastText: mode === "light" ? "#ffffff" : "rgba(0, 0, 0, 0.87)",
      },
      background: {
        default: mode === "light" ? "#fafafa" : "#121212",
        paper: mode === "light" ? "#ffffff" : "#1B1B1B",
      },
      text: {
        primary: mode === "light" ? "rgba(33, 33, 33, 0.92)" : "#ffffff",
        secondary: mode === "light" ? "rgba(33, 33, 33, 0.72)" : "rgba(255, 255, 255, 0.7)",
        disabled: mode === "light" ? "rgba(33, 33, 33, 0.24)" : "rgba(255, 255, 255, 0.5)",
      },
      action: {
        active: mode === "light" ? "rgba(33, 33, 33, 0.64)" : "rgba(255, 255, 255, 0.64)",
        hover: mode === "light" ? "rgba(33, 33, 33, 0.04)" : "rgba(255, 255, 255, 0.08)",
        selected: mode === "light" ? "rgba(33, 33, 33, 0.08)" : "rgba(255, 255, 255, 0.16)",
        disabled: mode === "light" ? "rgba(33, 33, 33, 0.26)" : "rgba(255, 255, 255, 0.3)",
        disabledBackground: mode === "light" ? "rgba(33, 33, 33, 0.12)" : "rgba(255, 255, 255, 0.12)",
        focus: mode === "light" ? "rgba(33, 33, 33, 0.12)" : "rgba(255, 255, 255, 0.12)",
      },
      divider: mode === "light" ? "rgba(33, 33, 33, 0.06)" : "rgba(255, 255, 255, 0.12)",
    },
    shape: {
      borderRadius: 16,
    },
    typography: {
      fontFamily: "inherit",
    },
    components: {
      MuiButton: {
        defaultProps: { disableElevation: true },
        styleOverrides: {
          root: { textTransform: "none" as const, borderRadius: "1rem" },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: { borderRadius: "9999px" },
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: { borderRadius: "1rem" },
        },
      },
      MuiCard: {
        defaultProps: { variant: "outlined" as const },
        styleOverrides: {
          root: {
            borderRadius: "1rem",
            boxShadow: "none",
            borderColor: mode === "light" ? "rgba(33, 33, 33, 0.06)" : "rgba(255, 255, 255, 0.12)",
          },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: { backgroundImage: "none" },
          outlined: {
            borderColor: mode === "light" ? "rgba(33, 33, 33, 0.06)" : "rgba(255, 255, 255, 0.12)",
          },
        },
      },
    },
  });
}

const lightTheme = buildTheme("light");
const darkTheme = buildTheme("dark");

export function AppThemeProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isDark, setIsDark] = React.useState(false);

  React.useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));

    const observer = new MutationObserver(() => {
      setIsDark(document.documentElement.classList.contains("dark"));
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });
    return () => observer.disconnect();
  }, []);

  return (
    <ThemeProvider theme={isDark ? darkTheme : lightTheme}>
      <CssBaseline enableColorScheme />
      {children}
    </ThemeProvider>
  );
}
