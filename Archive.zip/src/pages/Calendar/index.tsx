import { useCallback, useState, useRef, useEffect } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useAppSelector, useAppDispatch } from "@/store";
import { setCalendarViewMode, setAnchorDate } from "@/store/slices/calendarSlice";
import { setSessionFocus } from "@/store/slices/sessionsSlice";
import { setRequestFocus } from "@/store/slices/requestsSlice";
import { setOpenSession, setOpenRequest, setOpenAvailability, setOpenNotAvailable } from "@/store/slices/uiSlice";
import {
  selectAnchorDate,
  selectWeekStart,
  selectMonthStart,
  selectWeekDays,
  selectSessionsThisWeek,
  selectRequestsThisWeek,
  selectBusyThisWeek,
  selectAvailabilityEndDate,
  selectPendingRequestsThisWeek,
  selectIsCurrentPeriod,
} from "@/store/selectors/calendarSelectors";
import {
  addDays,
  addMonths,
  weekLabel,
  monthLabel,
  fmtTime,
  fmtTime12,
  toYmd,
} from "@/lib/helpers";
import { DOW, DOW_LONG, TIME_START, TIME_END, demoNow } from "@/lib/constants";
import type { NA, RequestSlot, Session } from "@/lib/types";

/* ─── helpers ─────────────────────────────────────────────────────────────── */

/** Overlap predicate per spec §8.3: aStart < bEnd && bStart < aEnd */
function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number) {
  return aStart < bEnd && bStart < aEnd;
}

/** Convert minutes-since-midnight to a percentage within the visible grid. */
function timeToPercent(mins: number) {
  return ((mins - TIME_START) / (TIME_END - TIME_START)) * 100;
}

/** Hours to render on the time axis (8 AM … 8 PM). */
const HOUR_LABELS: number[] = (() => {
  const arr: number[] = [];
  for (let m = TIME_START; m <= TIME_END; m += 60) arr.push(m);
  return arr;
})();

/** Format a Date as "Feb 16" */
function fmtShortDate(d: Date) {
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/** Session status color (§8.4) */
function sessionColors(confirmed: boolean, declined: boolean) {
  if (declined)
    return {
      bg: "rgba(244,63,94,0.12)",
      border: "error.main",
      text: "error.main",
      sub: "error.light",
    };
  if (confirmed)
    return {
      bg: "rgba(37,99,235,0.12)",
      border: "#2563eb",
      text: "#1e40af",
      sub: "#2563eb",
    };
  // Scheduled
  return {
    bg: "rgba(99,102,241,0.15)",
    border: "rgb(99,102,241)",
    text: "rgb(79,70,229)",
    sub: "rgb(99,102,241)",
  };
}

/** Request status color (§8.5) */
function requestColors(response: RequestSlot["response"]) {
  if (response === "available")
    return {
      bg: "rgba(37,99,235,0.10)",
      border: "#2563eb",
      text: "#1e40af",
      sub: "#2563eb",
    };
  if (response === "unavailable")
    return {
      bg: "rgba(244,63,94,0.10)",
      border: "rgb(244,63,94)",
      text: "#be123c",
      sub: "rgb(244,63,94)",
    };
  // Pending
  return {
    bg: "rgba(99,102,241,0.08)",
    border: "rgb(99,102,241)",
    text: "rgb(79,70,229)",
    sub: "rgb(99,102,241)",
  };
}

/* ═══════════════════════════════════════════════════════════════════════════ */

export default function CalendarPage() {
  const dispatch = useAppDispatch();

  /* ── redux state ──────────────────────────────────────────────────────── */
  const sessions = useAppSelector((s) => s.sessions.items);
  const confirmations = useAppSelector((s) => s.sessions.confirmations);
  const sessionDeclined = useAppSelector((s) => s.sessions.sessionDeclined);
  const calendarViewMode = useAppSelector((s) => s.calendar.calendarViewMode);
  const patterns = useAppSelector((s) => s.availability.patterns);
  const oneOffAvail = useAppSelector((s) => s.availability.oneOffAvail);
  const unavailable = useAppSelector((s) => s.availability.unavailable);
  const requests = useAppSelector((s) => s.requests.items);
  const maxPerWeek = useAppSelector((s) => s.availability.maxPerWeek);

  /* ── memoized selectors (§7) ──────────────────────────────────────────── */
  const anchorDate = useAppSelector(selectAnchorDate);
  const weekStart = useAppSelector(selectWeekStart);
  const monthStart = useAppSelector(selectMonthStart);
  const weekDays = useAppSelector(selectWeekDays);
  const availabilityEndDate = useAppSelector(selectAvailabilityEndDate);
  const rangeEndYmd = availabilityEndDate;
  const pendingRequestsThisWeek = useAppSelector(selectPendingRequestsThisWeek);
  const sessionsThisWeek = useAppSelector(selectSessionsThisWeek);
  const requestsThisWeek = useAppSelector(selectRequestsThisWeek);
  const busyThisWeek = useAppSelector(selectBusyThisWeek);
  const isCurrentPeriod = useAppSelector(selectIsCurrentPeriod);

  /* ── navigation ───────────────────────────────────────────────────────── */
  const navPrev = () => {
    if (calendarViewMode === "week") {
      dispatch(setAnchorDate(addDays(anchorDate, -7).toISOString()));
    } else {
      dispatch(setAnchorDate(addMonths(anchorDate, -1).toISOString()));
    }
  };
  const navNext = () => {
    if (calendarViewMode === "week") {
      dispatch(setAnchorDate(addDays(anchorDate, 7).toISOString()));
    } else {
      dispatch(setAnchorDate(addMonths(anchorDate, 1).toISOString()));
    }
  };
  const navCurrent = () => {
    dispatch(setAnchorDate(demoNow.toISOString()));
  };

  /* ── Month picker dropdown ────────────────────────────────────────────── */
  const [monthMenuOpen, setMonthMenuOpen] = useState(false);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, right: 0 });
  const monthPickerRef = useRef<HTMLDivElement>(null);

  const openMonthMenu = () => {
    if (monthPickerRef.current) {
      const rect = monthPickerRef.current.getBoundingClientRect();
      setDropdownPos({ top: rect.bottom + 4, right: window.innerWidth - rect.right });
    }
    setMonthMenuOpen(true);
  };

  useEffect(() => {
    if (!monthMenuOpen) return;
    const handler = (e: MouseEvent) => {
      if (monthPickerRef.current && !monthPickerRef.current.contains(e.target as Node)) {
        setMonthMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [monthMenuOpen]);

  // Build list: 6 months back → 6 months forward from demoNow
  const monthOptions = Array.from({ length: 13 }, (_, i) => {
    const d = addMonths(demoNow, i - 6);
    return { label: d.toLocaleDateString("en-US", { month: "long", year: "numeric" }), date: d };
  });

  /* ── Month day-click → switch to week view (§9.5) ─────────────────── */
  const handleMonthDayClick = useCallback(
    (d: Date) => {
      const ymd = toYmd(d);
      // §9.4: beyond rangeEndYmd → no action
      if (ymd > rangeEndYmd) return;
      dispatch(setAnchorDate(d.toISOString()));
      dispatch(setCalendarViewMode("week"));
    },
    [dispatch, rangeEndYmd]
  );

  /* ═══════════════════════════════════════════════════════════════════════ */
  return (
    <>
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5" aria-hidden="true" />
          <Typography variant="h5" sx={{ fontWeight: 700 }}>Calendar</Typography>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outlined"
            size="small"
            aria-label="Mark leave"
            sx={{ borderRadius: '9999px', textTransform: 'none' }}
            onClick={() => dispatch(setOpenNotAvailable(true))}
          >
            Mark leave
          </Button>
          <Button
            variant="contained"
            size="small"
            aria-label="Add availability"
            sx={{ borderRadius: '9999px', textTransform: 'none', bgcolor: 'text.primary', color: 'background.default', '&:hover': { bgcolor: 'text.secondary' } }}
            onClick={() => dispatch(setOpenAvailability(true))}
          >
            Add availability
          </Button>
        </div>
      </div>

      {/* ── Stats pills ────────────────────────────────────────────────── */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Chip
          label={`Max sessions/week:  ${maxPerWeek}`}
          variant="outlined"
          size="small"
          sx={{ borderRadius: '9999px' }}
        />
        <Chip
          label={`Availability through  ${availabilityEndDate}`}
          variant="outlined"
          size="small"
          sx={{ borderRadius: '9999px' }}
        />
        <Chip
          label={`Requests this week:  ${pendingRequestsThisWeek}`}
          variant="outlined"
          size="small"
          sx={{ borderRadius: '9999px' }}
        />
      </div>

      {/* ── View toggle + navigation ───────────────────────────────────── */}
      <div className="mt-4 flex items-center justify-between gap-3">
        {/* Left side: Week/Month toggle */}
        <Box
          sx={{
            display: 'inline-flex',
            gap: 0.5,
            border: 1,
            borderColor: 'divider',
            borderRadius: '9999px',
            p: 0.5,
          }}
        >
          {(["week", "month"] as const).map((mode) => (
            <Button
              key={mode}
              variant={calendarViewMode === mode ? "contained" : "text"}
              size="small"
              sx={{
                borderRadius: '9999px',
                fontSize: '0.8rem',
                textTransform: 'capitalize',
                minWidth: 64,
                px: 2,
              }}
              onClick={() => dispatch(setCalendarViewMode(mode))}
              aria-label={`Switch to ${mode} view`}
            >
              {mode}
            </Button>
          ))}
        </Box>

        {/* Right side: date label + Prev/Next */}
        <div className="flex items-center gap-2">
          <div ref={monthPickerRef} style={{ position: 'relative' }}>
            <Chip
              label={
                <span className="flex items-center gap-1">
                  {calendarViewMode === "week" ? weekLabel(anchorDate) : monthLabel(anchorDate)}
                  <ChevronDown className="h-3.5 w-3.5" style={{ transform: monthMenuOpen ? 'rotate(180deg)' : undefined, transition: 'transform 0.15s' }} />
                </span>
              }
              variant="outlined"
              onClick={() => monthMenuOpen ? setMonthMenuOpen(false) : openMonthMenu()}
              sx={{ borderRadius: '9999px', fontSize: '0.875rem', fontWeight: 500, cursor: 'pointer' }}
            />
            {monthMenuOpen && (
              <div
                style={{
                  position: 'fixed',
                  top: dropdownPos.top,
                  right: dropdownPos.right,
                  zIndex: 1300,
                  minWidth: 180,
                  maxHeight: 320,
                  overflowY: 'auto',
                  borderRadius: 8,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
                  backgroundColor: '#ffffff',
                  border: '1px solid #e0e0e0',
                }}
              >
                {monthOptions.map(({ label, date }) => {
                  const isSelected = monthLabel(anchorDate) === label;
                  return (
                    <div
                      key={label}
                      onClick={() => {
                        dispatch(setAnchorDate(date.toISOString()));
                        setMonthMenuOpen(false);
                      }}
                      style={{
                        padding: '8px 16px',
                        cursor: 'pointer',
                        fontSize: '0.875rem',
                        fontWeight: isSelected ? 600 : 400,
                        backgroundColor: isSelected ? 'rgba(25,118,210,0.08)' : undefined,
                        color: isSelected ? '#1976d2' : '#212121',
                      }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.backgroundColor = isSelected ? 'rgba(25,118,210,0.12)' : '#f5f5f5'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.backgroundColor = isSelected ? 'rgba(25,118,210,0.08)' : ''; }}
                    >
                      {label}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="outlined"
              size="small"
              aria-label="Previous period"
              sx={{ borderRadius: '9999px', minWidth: 0, height: 36, width: 36, p: 0 }}
              onClick={navPrev}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outlined"
              size="small"
              aria-label="Next period"
              sx={{ borderRadius: '9999px', minWidth: 0, height: 36, width: 36, p: 0 }}
              onClick={navNext}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/* ── WEEK VIEW ─────────────────────────────────────────────────── */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {calendarViewMode === "week" && (
        <>
          {/* ── Mobile list view (below md) ─────────────────────────────── */}
          <div className="mt-3 block md:hidden">
            <div className="grid grid-cols-7 gap-2">
              {weekDays.map((d, i) => {
                const ymd = toYmd(d);
                const daySessions = sessionsThisWeek.filter(
                  (s) => s.dateYmd === ymd && !sessionDeclined[s.id]
                );
                const dayRequests = requestsThisWeek.filter(
                  (r) => r.dateYmd === ymd && r.response === "pending"
                );
                const isToday = ymd === toYmd(demoNow);
                return (
                  <div key={i} className="min-h-[120px]">
                    <div className="mb-1 text-center">
                      <Typography
                        variant="caption"
                        sx={{ fontWeight: 600, ...(isToday && { color: 'primary.main' }) }}
                      >
                        {DOW[i]}
                      </Typography>
                      <Box
                        sx={{
                          mx: 'auto',
                          mt: 0.5,
                          height: 24,
                          width: 24,
                          borderRadius: '50%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '0.75rem',
                          fontWeight: 500,
                          ...(isToday && { bgcolor: 'primary.main', color: 'primary.contrastText' }),
                        }}
                      >
                        {d.getDate()}
                      </Box>
                    </div>
                    <div className="space-y-1">
                      {/* Sessions (§14: preserve status colors) */}
                      {daySessions.map((s) => {
                        const confirmed = !!confirmations[s.id];
                        const colors = sessionColors(confirmed, false);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            className="w-full rounded-lg px-1.5 py-1 text-left text-[10px] leading-tight transition-colors"
                            style={{ backgroundColor: colors.bg }}
                            onClick={() => {
                              dispatch(setSessionFocus(s));
                              dispatch(setOpenSession(true));
                            }}
                            aria-label={`Session: ${s.title}, ${fmtTime12(s.start)} to ${fmtTime12(s.end)}`}
                          >
                            <div className="font-medium truncate">
                              {s.title.replace("Mentor Session: ", "")}
                            </div>
                            <div style={{ color: "var(--mui-palette-text-secondary)" }}>
                              {fmtTime12(s.start)}
                            </div>
                          </button>
                        );
                      })}
                      {/* Requests on mobile */}
                      {dayRequests.map((r) => (
                        <button
                          key={r.id}
                          type="button"
                          className="w-full rounded-lg px-1.5 py-1 text-left text-[10px] leading-tight transition-colors"
                          style={{ backgroundColor: "rgba(99,102,241,0.08)", border: "1px dashed rgb(99,102,241)" }}
                          onClick={() => {
                            dispatch(setRequestFocus(r));
                            dispatch(setOpenRequest(true));
                          }}
                          aria-label={`Request: ${r.title}, ${fmtTime12(r.start)} to ${fmtTime12(r.end)}`}
                        >
                          <div className="font-medium truncate">
                            {r.title}
                          </div>
                          <div style={{ color: "var(--mui-palette-text-secondary)" }}>
                            {fmtTime12(r.start)}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── Desktop time-grid view (md and above) ───────────────────── */}
          <Card variant="outlined" sx={{ mt: 2, overflow: 'hidden', display: { xs: 'none', md: 'block' } }}>
            {/* Single scroll container — header + body share same width so columns align */}
            <Box sx={{ overflowY: 'auto', height: 600 }}>
            {/* Day-of-week header row — sticky so it stays visible while scrolling */}
            <Box
              sx={{
                position: 'sticky',
                top: 0,
                zIndex: 10,
                bgcolor: 'background.paper',
                display: 'grid',
                gridTemplateColumns: '60px repeat(7, 1fr)',
                borderBottom: 1,
                borderColor: 'divider',
              }}
            >
              {/* "Time" label */}
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 1.5 }}>
                <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 500 }}>
                  Time
                </Typography>
              </Box>
              {weekDays.map((d, i) => {
                const ymd = toYmd(d);
                const isToday = ymd === toYmd(demoNow);
                return (
                  <Box
                    key={i}
                    sx={{
                      textAlign: 'center',
                      py: 1.5,
                      borderLeft: 1,
                      borderColor: 'divider',
                    }}
                    aria-label={`${DOW_LONG[i]} ${fmtShortDate(d)}`}
                  >
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 700, ...(isToday && { color: 'primary.main' }) }}
                    >
                      {DOW[i]}
                    </Typography>
                    <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                      {fmtShortDate(d)}
                    </Typography>
                  </Box>
                );
              })}
            </Box>

            {/* Time grid body */}
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: '60px repeat(7, 1fr)',
                  position: 'relative',
                  height: HOUR_LABELS.length * 50,
                }}
              >
                {/* ── Time labels + horizontal grid lines ──────────────── */}
                {HOUR_LABELS.map((mins) => {
                  const top = `${timeToPercent(mins)}%`;
                  return (
                    <div key={mins} className="contents">
                      {/* time label */}
                      <Typography
                        variant="caption"
                        sx={{
                          position: 'absolute',
                          left: 0,
                          width: 60,
                          textAlign: 'right',
                          pr: 1,
                          top,
                          transform: 'translateY(-50%)',
                          color: 'text.secondary',
                          fontSize: '0.65rem',
                        }}
                      >
                        {fmtTime(mins)}
                      </Typography>
                      {/* horizontal line */}
                      <Box
                        sx={{
                          position: 'absolute',
                          top,
                          left: 60,
                          right: 0,
                          height: '1px',
                          bgcolor: 'divider',
                        }}
                      />
                    </div>
                  );
                })}

                {/* ── Day columns with overlap handling (§8.3) ──────────── */}
                {weekDays.map((d, colIdx) => {
                  const ymd = toYmd(d);
                  const dayLong = DOW_LONG[colIdx];

                  /* raw data for this day */
                  const rawAvailBlocks = patterns.filter((p) => p.days.includes(dayLong));
                  const rawOneOffBlocks = oneOffAvail.filter((b) => b.dateYmd === ymd);
                  const naBlocks = unavailable.filter((n) => n.dateYmd === ymd);
                  const rawBusyBlocks = busyThisWeek.filter((b) => b.dateYmd === ymd);
                  const daySessions = sessionsThisWeek.filter((s) => s.dateYmd === ymd);
                  const dayRequests = requestsThisWeek.filter((r) => r.dateYmd === ymd);

                  /* ── §8.3 overlap filtering ────────────────────────── */

                  // Collect all "occupied" intervals (drawn sessions, requests, NA)
                  const occupiedIntervals: Array<{ start: number; end: number }> = [];

                  // Sessions that are drawn (not declined)
                  const drawnSessions = daySessions.filter((s) => !sessionDeclined[s.id]);
                  drawnSessions.forEach((s) => occupiedIntervals.push({ start: s.start, end: s.end }));

                  // Declined sessions — their time slots
                  const declinedSessions = daySessions.filter((s) => !!sessionDeclined[s.id]);

                  // Requests add to occupied
                  dayRequests.forEach((r) => occupiedIntervals.push({ start: r.start, end: r.end }));

                  // §8.3: Hide busy blocks if they collide with a declined session block
                  const filteredBusyBlocks = rawBusyBlocks.filter((b) => {
                    return !declinedSessions.some((s) =>
                      overlaps(b.start, b.end, s.start, s.end)
                    );
                  });
                  filteredBusyBlocks.forEach((b) => occupiedIntervals.push({ start: b.start, end: b.end }));

                  // §8.3: For overlapping NA (leave) blocks, keep only the most recent by createdAt
                  // Also hide leave blocks tied to sessionId if the same session is drawn in that day
                  const filteredNaBlocks = (() => {
                    // Step 1: Remove NA blocks whose sessionId maps to a drawn session
                    const afterSessionFilter = naBlocks.filter((n) => {
                      if (n.sessionId) {
                        // Hide if this session is drawn (not declined)
                        return !drawnSessions.some((s) => s.id === n.sessionId);
                      }
                      return true;
                    });
                    // Step 2: For overlapping NA blocks, keep only the most recent by createdAt
                    const result: NA[] = [];
                    for (const n of afterSessionFilter) {
                      const overlapping = result.findIndex((existing) =>
                        overlaps(existing.start, existing.end, n.start, n.end)
                      );
                      if (overlapping >= 0) {
                        const existingCreated = result[overlapping].createdAt ?? 0;
                        const newCreated = n.createdAt ?? 0;
                        if (newCreated > existingCreated) {
                          result[overlapping] = n;
                        }
                        // else keep existing
                      } else {
                        result.push(n);
                      }
                    }
                    return result;
                  })();
                  filteredNaBlocks.forEach((n) => occupiedIntervals.push({ start: n.start, end: n.end }));

                  // §8.3: Hide availability placeholders that overlap any drawn occupied interval
                  const filteredAvailBlocks = rawAvailBlocks.filter((p) => {
                    return !occupiedIntervals.some((occ) =>
                      overlaps(p.start, p.end, occ.start, occ.end)
                    );
                  });
                  const filteredOneOffBlocks = rawOneOffBlocks.filter((b) => {
                    return !occupiedIntervals.some((occ) =>
                      overlaps(b.start, b.end, occ.start, occ.end)
                    );
                  });

                  return (
                    <Box
                      key={colIdx}
                      sx={{
                        position: 'relative',
                        gridColumn: colIdx + 2,
                        gridRow: 1,
                        borderLeft: 1,
                        borderColor: 'divider',
                      }}
                    >
                      {/* §8.2 Draw order: 1. Busy (lowest) */}
                      {filteredBusyBlocks.map((b) => (
                        <Box
                          key={`busy-${b.id}`}
                          sx={{
                            position: 'absolute',
                            left: 0,
                            right: 0,
                            top: `${timeToPercent(b.start)}%`,
                            height: `${timeToPercent(b.end) - timeToPercent(b.start)}%`,
                            bgcolor: 'rgba(156,163,175,0.25)',
                            borderLeft: '3px solid rgb(156,163,175)',
                            borderRadius: '4px',
                            zIndex: 1,
                            pointerEvents: 'none',
                            px: 0.5,
                          }}
                        >
                          <Typography sx={{ fontSize: 9, lineHeight: '14px', color: 'text.secondary' }} noWrap>
                            {b.title}
                          </Typography>
                        </Box>
                      ))}

                      {/* §8.2 Draw order: 2. Leave (unavailable) */}
                      {filteredNaBlocks.map((n) => (
                        <Box
                          key={`na-${n.id}`}
                          sx={{
                            position: 'absolute',
                            left: 0,
                            right: 0,
                            top: `${timeToPercent(n.start)}%`,
                            height: `${timeToPercent(n.end) - timeToPercent(n.start)}%`,
                            bgcolor: 'rgba(244,63,94,0.12)',
                            borderLeft: '3px solid',
                            borderColor: 'error.main',
                            borderRadius: '4px',
                            backgroundImage:
                              'repeating-linear-gradient(135deg, transparent, transparent 4px, rgba(244,63,94,0.15) 4px, rgba(244,63,94,0.15) 5px)',
                            zIndex: 2,
                            px: 0.5,
                            pt: 0.25,
                            overflow: 'hidden',
                          }}
                        >
                          <Typography sx={{ fontSize: 10, fontWeight: 600, color: 'error.dark' }}>
                            Not available
                          </Typography>
                          {n.reason && (
                            <Typography sx={{ fontSize: 9, color: 'error.dark' }} noWrap>
                              {n.reason}
                            </Typography>
                          )}
                        </Box>
                      ))}

                      {/* §8.2 Draw order: 3. Availability placeholders */}
                      {filteredAvailBlocks.map((p) => (
                        <Box
                          key={`avail-${p.id}`}
                          sx={{
                            position: 'absolute',
                            left: 0,
                            right: 0,
                            top: `${timeToPercent(p.start)}%`,
                            height: `${timeToPercent(p.end) - timeToPercent(p.start)}%`,
                            bgcolor: 'rgba(34,197,94,0.12)',
                            borderLeft: '3px solid',
                            borderColor: 'success.main',
                            borderRadius: '4px',
                            zIndex: 3,
                            px: 0.5,
                            pt: 0.5,
                            overflow: 'hidden',
                          }}
                        >
                          <Typography sx={{ fontSize: 10, fontWeight: 600, color: 'success.dark' }}>
                            Available
                          </Typography>
                          <Typography sx={{ fontSize: 9, color: 'success.dark' }}>
                            {fmtTime(p.start)}–{fmtTime(p.end)}
                          </Typography>
                        </Box>
                      ))}

                      {/* One-off availability blocks */}
                      {filteredOneOffBlocks.map((b) => (
                        <Box
                          key={`oneoff-${b.id}`}
                          sx={{
                            position: 'absolute',
                            left: 0,
                            right: 0,
                            top: `${timeToPercent(b.start)}%`,
                            height: `${timeToPercent(b.end) - timeToPercent(b.start)}%`,
                            bgcolor: 'rgba(34,197,94,0.12)',
                            borderLeft: '3px solid',
                            borderColor: 'success.main',
                            borderRadius: '4px',
                            zIndex: 3,
                            px: 0.5,
                            pt: 0.5,
                            overflow: 'hidden',
                          }}
                        >
                          <Typography sx={{ fontSize: 10, fontWeight: 600, color: 'success.dark' }}>
                            Available
                          </Typography>
                          <Typography sx={{ fontSize: 9, color: 'success.dark' }}>
                            {fmtTime(b.start)}–{fmtTime(b.end)}
                          </Typography>
                        </Box>
                      ))}

                      {/* §8.2 Draw order: 4. Requests */}
                      {dayRequests.map((r) => {
                        const rColors = requestColors(r.response);
                        return (
                          <Box
                            key={`req-${r.id}`}
                            component="button"
                            onClick={() => {
                              dispatch(setRequestFocus(r));
                              dispatch(setOpenRequest(true));
                            }}
                            aria-label={`Request: ${r.title}, ${fmtTime12(r.start)} to ${fmtTime12(r.end)}, status ${r.response}`}
                            sx={{
                              position: 'absolute',
                              left: 0,
                              right: 0,
                              top: `${timeToPercent(r.start)}%`,
                              height: `${timeToPercent(r.end) - timeToPercent(r.start)}%`,
                              bgcolor: rColors.bg,
                              border: `1.5px dashed ${rColors.border}`,
                              borderRadius: '4px',
                              zIndex: 4,
                              px: 0.5,
                              pt: 0.25,
                              textAlign: 'left',
                              cursor: 'pointer',
                              overflow: 'hidden',
                              width: '100%',
                              fontFamily: 'inherit',
                            }}
                          >
                            <Typography
                              sx={{ fontSize: 10, fontWeight: 700, lineHeight: '14px', color: rColors.text }}
                              noWrap
                            >
                              Request
                            </Typography>
                            <Typography
                              sx={{ fontSize: 10, lineHeight: '14px', color: rColors.text }}
                              noWrap
                            >
                              {r.title}
                            </Typography>
                            <Typography
                              sx={{ fontSize: 9, lineHeight: '12px', color: rColors.sub }}
                            >
                              {fmtTime(r.start)}–{fmtTime(r.end)}
                            </Typography>
                          </Box>
                        );
                      })}

                      {/* §8.2 Draw order: 5. Sessions (top) */}
                      {daySessions.map((s) => {
                        const declined = !!sessionDeclined[s.id];
                        const confirmed = !!confirmations[s.id];
                        const sColors = sessionColors(confirmed, declined);
                        const statusLabel = declined
                          ? "Declined"
                          : confirmed
                            ? "Confirmed"
                            : "Scheduled";
                        return (
                          <Box
                            key={`sess-${s.id}`}
                            component="button"
                            onClick={() => {
                              dispatch(setSessionFocus(s));
                              dispatch(setOpenSession(true));
                            }}
                            aria-label={`${statusLabel} session: ${s.title}, ${fmtTime12(s.start)} to ${fmtTime12(s.end)}`}
                            sx={{
                              position: 'absolute',
                              left: 0,
                              right: 0,
                              top: `${timeToPercent(s.start)}%`,
                              height: `${timeToPercent(s.end) - timeToPercent(s.start)}%`,
                              bgcolor: sColors.bg,
                              borderLeft: '3px solid',
                              borderColor: sColors.border,
                              borderRadius: '4px',
                              zIndex: 5,
                              px: 0.5,
                              pt: 0.25,
                              textAlign: 'left',
                              cursor: 'pointer',
                              textDecoration: declined ? 'line-through' : 'none',
                              overflow: 'hidden',
                              border: 'none',
                              borderLeftWidth: '3px',
                              borderLeftStyle: 'solid',
                              width: '100%',
                              fontFamily: 'inherit',
                            }}
                          >
                            <Typography
                              sx={{
                                fontSize: 10,
                                fontWeight: 700,
                                lineHeight: '14px',
                                color: sColors.text,
                              }}
                              noWrap
                            >
                              {/* §16: Color state encoded via text label */}
                              {statusLabel}
                            </Typography>
                            <Typography
                              sx={{
                                fontSize: 10,
                                lineHeight: '14px',
                                color: sColors.text,
                              }}
                              noWrap
                            >
                              {s.title.replace("Mentor Session: ", "")}
                            </Typography>
                            <Typography
                              sx={{
                                fontSize: 9,
                                lineHeight: '12px',
                                color: sColors.sub,
                              }}
                              noWrap
                            >
                              {fmtTime(s.start)}–{fmtTime(s.end)} &bull; {s.sessionType}
                            </Typography>
                          </Box>
                        );
                      })}
                    </Box>
                  );
                })}

                {/* Time-column spacer */}
                <Box sx={{ position: 'relative', gridColumn: 1, gridRow: 1 }} />
              </Box>
            </Box>
          </Card>

          {/* ── Legend bar ──────────────────────────────────────────────── */}
          <Box
            sx={{
              mt: 1.5,
              display: 'flex',
              alignItems: 'center',
              gap: 3,
              flexWrap: 'wrap',
            }}
          >
            <Typography variant="caption" sx={{ fontWeight: 700 }}>Key</Typography>
            {[
              { color: 'rgb(99,102,241)', label: 'Scheduled / Requests' },
              { color: '#2563eb', label: 'Confirmed sessions' },
              { color: 'rgb(34,197,94)', label: 'Availability' },
              { color: 'rgb(244,63,94)', label: 'Not available' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-1.5">
                <Box
                  sx={{
                    width: 8,
                    height: 8,
                    borderRadius: '50%',
                    bgcolor: item.color,
                    flexShrink: 0,
                  }}
                />
                <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                  {item.label}
                </Typography>
              </div>
            ))}
          </Box>
        </>
      )}

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/* ── MONTH VIEW ────────────────────────────────────────────────── */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {calendarViewMode === "month" && (
        <>
          <Card variant="outlined" sx={{ mt: 2, p: 2 }}>
            {/* §9.1 Sunday-first visual month grid — but we use Monday-first to match week view DOW header */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: 0.5,
                textAlign: 'center',
                mb: 1,
              }}
            >
              {DOW.map((d) => (
                <Typography key={d} variant="caption" sx={{ fontWeight: 600, color: 'text.secondary' }}>
                  {d}
                </Typography>
              ))}
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 0.5 }}>
              {(() => {
                const dt = new Date(monthStart);
                const day = dt.getDay();
                // Monday-first: shift so Monday = column 0
                const diff = day === 0 ? -6 : 1 - day;
                dt.setDate(dt.getDate() + diff);
                dt.setHours(0, 0, 0, 0);
                const cells = Array.from({ length: 42 }, (_, i) => addDays(dt, i));

                return cells.map((d, i) => {
                  const ymd = toYmd(d);
                  const isCurrentMonth = d.getMonth() === monthStart.getMonth();
                  const isBeyondRange = ymd > rangeEndYmd;
                  const isDisabled = isBeyondRange;

                  /* §9.2 Event composition per day from all sources */
                  const dayLong = DOW_LONG[d.getDay() === 0 ? 6 : d.getDay() - 1]; // map JS day to DOW_LONG index
                  const dayAvail = patterns.filter((p) => p.days.includes(dayLong));
                  const dayOneOff = oneOffAvail.filter((b) => b.dateYmd === ymd);
                  const daySessions = sessions.filter(
                    (s) => s.dateYmd === ymd
                  );
                  const dayRequests = requests.filter((r) => r.dateYmd === ymd);
                  const dayNA = unavailable.filter((n) => n.dateYmd === ymd);

                  /* §9.3 Sorting priority: leave first, session/confirmed next, request next, availability last */
                  type EventChip = { key: string; label: string; type: "leave" | "session" | "request" | "availability"; color: string; bg: string };
                  const chips: EventChip[] = [];

                  // Leave tags
                  dayNA.forEach((n) =>
                    chips.push({
                      key: `na-${n.id}`,
                      label: n.reason || "Unavailable",
                      type: "leave",
                      color: "#be123c",
                      bg: "rgba(244,63,94,0.12)",
                    })
                  );

                  // Session tags (tone by confirmed/declined/scheduled)
                  daySessions.forEach((s) => {
                    const declined = !!sessionDeclined[s.id];
                    const confirmed = !!confirmations[s.id];
                    const sColors = sessionColors(confirmed, declined);
                    const shortTitle = s.title.replace("Mentor Session: ", "");
                    chips.push({
                      key: `sess-${s.id}`,
                      label: shortTitle,
                      type: "session",
                      color: sColors.text,
                      bg: sColors.bg,
                    });
                  });

                  // Request tags (tone by response)
                  dayRequests.forEach((r) => {
                    const rColors = requestColors(r.response);
                    chips.push({
                      key: `req-${r.id}`,
                      label: r.title,
                      type: "request",
                      color: rColors.text,
                      bg: rColors.bg,
                    });
                  });

                  // Availability tags (recurring + one-off)
                  dayAvail.forEach((p) =>
                    chips.push({
                      key: `avail-${p.id}`,
                      label: `${fmtTime(p.start)}–${fmtTime(p.end)}`,
                      type: "availability",
                      color: "#15803d",
                      bg: "rgba(34,197,94,0.12)",
                    })
                  );
                  dayOneOff.forEach((b) =>
                    chips.push({
                      key: `oneoff-${b.id}`,
                      label: `${fmtTime(b.start)}–${fmtTime(b.end)}`,
                      type: "availability",
                      color: "#15803d",
                      bg: "rgba(34,197,94,0.12)",
                    })
                  );

                  // Sort by priority: leave(0) → session(1) → request(2) → availability(3)
                  const priorityMap: Record<string, number> = { leave: 0, session: 1, request: 2, availability: 3 };
                  chips.sort((a, b) => priorityMap[a.type] - priorityMap[b.type]);

                  // §9.1: show up to 3 chips and +N more
                  const visibleChips = chips.slice(0, 3);
                  const moreCount = chips.length - 3;

                  return (
                    <Box
                      key={i}
                      onClick={isDisabled ? undefined : () => handleMonthDayClick(d)}
                      role="button"
                      tabIndex={isDisabled ? -1 : 0}
                      onKeyDown={
                        isDisabled
                          ? undefined
                          : (e: React.KeyboardEvent) => {
                              if (e.key === "Enter" || e.key === " ") {
                                e.preventDefault();
                                handleMonthDayClick(d);
                              }
                            }
                      }
                      aria-label={`${ymd}${chips.length > 0 ? `, ${chips.length} events` : ""}${isDisabled ? ", disabled" : ""}`}
                      sx={{
                        minHeight: 72,
                        borderRadius: 1,
                        border: 1,
                        borderColor: 'divider',
                        p: 0.5,
                        fontSize: '0.75rem',
                        // §9.4: beyond range → disabled, reduced opacity
                        opacity: isDisabled ? 0.35 : isCurrentMonth ? 1 : 0.5,
                        cursor: isDisabled ? 'default' : 'pointer',
                        '&:hover': isDisabled ? {} : { bgcolor: 'action.hover' },
                        transition: 'background-color 0.15s',
                      }}
                    >
                      <Typography
                        variant="caption"
                        sx={{
                          fontWeight: 500,
                          ...(ymd === toYmd(demoNow) && {
                            bgcolor: 'primary.main',
                            color: 'primary.contrastText',
                            borderRadius: '50%',
                            width: 22,
                            height: 22,
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }),
                        }}
                      >
                        {d.getDate()}
                      </Typography>
                      {visibleChips.map((chip) => (
                        <Box
                          key={chip.key}
                          sx={{
                            mt: 0.25,
                            borderRadius: 0.5,
                            bgcolor: chip.bg,
                            color: chip.color,
                            px: 0.5,
                            fontSize: '0.5625rem',
                            lineHeight: '14px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {chip.label}
                        </Box>
                      ))}
                      {moreCount > 0 && (
                        <Typography variant="caption" sx={{ fontSize: '0.5625rem', color: 'text.secondary' }}>
                          +{moreCount} more
                        </Typography>
                      )}
                    </Box>
                  );
                });
              })()}
            </Box>
          </Card>
        </>
      )}
    </>
  );
}
